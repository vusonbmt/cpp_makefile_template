#include <stdio.h>

int main() {
    printf("Hello, world! Son huhu! \n");
    return 0;
}
